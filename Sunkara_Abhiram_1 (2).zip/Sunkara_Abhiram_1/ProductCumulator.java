import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
public class ProductCumulator{
    public void ProductFromKeyboard(){
        Scanner input = new Scanner(System.in);
        int product = 1;
        int number = 0;
        while (number > 0){
            number = input.nextInt();
            if (number > 0){
                product*=number;
            }
        }
        System.out.println("The product of input values is: " + product);
    }

    public void ProductFromFile(String filename){
        int product = 1;
        String curtoken;
        File file = new File(filename);
        Scanner fscnr = new Scanner(file);
        while(fscnr.hasNextInt()){
            curtoken = Integer.parseInt(fscnr.nextInt());
            while(Integer.parseInt(curtoken) > 0){
                product*=Integer.parseInt(curtoken);

            }
        }
    }

    public static void main(String[] args) throws FileNotFoundException{
        String curtoken;
        File file = new File("C:/Users/aksun/Documents/sample_intesequence.txt");
        
        ProductCumulator pro = new ProductCumulator();
        pro.ProductFromKeyboard();
    }
}