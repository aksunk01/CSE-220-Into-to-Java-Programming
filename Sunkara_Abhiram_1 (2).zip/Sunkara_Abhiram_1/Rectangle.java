import java.util.Scanner;
public class Rectangle{
    private double height, width;
    public Rectangle(){
        this.height = 1;
        this.width = 1;
    }
    public Rectangle(double x, double y){
        this.height = x;
        this.width = y;
    }

    public void printDims(){
        System.out.println("This rectangle has height " + height+ " and width " + width);

    }

    public void printArea(){
        System.out.println("This rectangle has and area of " + height*width + " units squared");
    }

    public static double printMaxSide(double height, double width){
        if(height > width){
            return height;
        }else if (width > height){
            return width;
        }else{
            return height;
        }
        
    }

    public void IsValid(double height, double width){
        if(height >= 0 && width >= 0){
            System.out.println("This is a valid rectangle");
        }else{
            System.out.println("This is not a valid rectangle");
        }
    }

    public static void Gap(){
        System.out.println("----------------------");
    }


    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double rheight = 0;
        double rwidth = 0;
        int choice = 0;
        Rectangle rect;

        System.out.println("Set dimensions to 1x1");
        System.out.println("1) Yes");
        System.out.println("2) No");
        choice = input.nextInt();


        if(choice == 1){
            rect = new Rectangle();
        }else if (choice == 2){
            System.out.print("Enter the height of the rectangle: ");
            rheight = input.nextDouble();
            System.out.print("Enter the width of the rectangle: ");
            rwidth = input.nextDouble();
            rect = new Rectangle(rheight, rwidth);
        }else{
            return;
        }

        
        
        Gap();
        rect.printArea();
        Gap();
        rect.printDims();
        Gap();
        rect.IsValid(rheight, rwidth);
        Gap();
        System.out.println("Max side was: "+rect.printMaxSide(rheight, rwidth));
        Gap();
    }
}