import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;

public class SmileyFace extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create a Pane for the layout
        Pane pane = new Pane();
        pane.setPadding(new Insets(20));

        // Create the head
        Circle head = new Circle(100, 100, 50);
        head.setFill(Color.YELLOW);
        head.setStroke(Color.BLACK);

        // Create the eyes
        Ellipse leftEye = new Ellipse(70, 80, 10, 5);
        leftEye.setFill(Color.WHITE);
        leftEye.setStroke(Color.BLACK);
        Circle leftPupil = new Circle(70, 80, 2);
        leftPupil.setFill(Color.BLACK);

        Ellipse rightEye = new Ellipse(130, 80, 10, 5);
        rightEye.setFill(Color.WHITE);
        rightEye.setStroke(Color.BLACK);
        Circle rightPupil = new Circle(130, 80, 2);
        rightPupil.setFill(Color.BLACK);

        // Create the mouth
        Arc mouth = new Arc(100, 130, 30, 20, 210, 330);
        mouth.setFill(Color.BLACK);
        mouth.setStroke(Color.BLACK);

        // Create the nose
        Polygon nose = new Polygon(90, 90, 100, 110, 110, 90);
        nose.setFill(Color.ORANGE);
        nose.setStroke(Color.BLACK);

        // Add all shapes to the Pane
        pane.getChildren().addAll(head, leftEye, leftPupil, rightEye, rightPupil, mouth, nose);

        // Create a Scene and set the stage
        Scene scene = new Scene(pane, 200, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Smiley Face");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}