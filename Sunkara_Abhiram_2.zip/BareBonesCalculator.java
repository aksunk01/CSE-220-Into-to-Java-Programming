import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.control.Button;
import javafx.geometry.Insets;

public class BareBonesCalculator extends Application{
    private TextField leftField, rightField;
    private Label outputLabel;
    private String currentOperator;
    
    public void start(Stage primaryStage){
        leftField = new TextField();
        rightField = new TextField();
        outputLabel = new Label();
        
        Button mult = new Button("x");
        Button add = new Button("+");
        Button sub = new Button("-");
        
        mult.setOnAction(event -> performOperation("x"));
        sub.setOnAction(event -> performOperation("-"));
        add.setOnAction(event -> performOperation("+"));
        
        
        GridPane grid = new GridPane();
        
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);

        grid.add(leftField, 0, 0);
        grid.add(add, 1, 0);
        grid.add(rightField, 2, 0);
        grid.add(mult, 1, 2);
        grid.add(sub, 1, 1);
        grid.add(outputLabel, 2, 1);
        
        
        
        Scene scene = new Scene(grid, 300, 150);
        primaryStage.setTitle("BareBonesCalculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    private void performOperation(String operator){
        try{
            double left = Double.parseDouble(leftField.getText());
            double right = Double.parseDouble(rightField.getText());
            
            switch(operator){
                case "*":
                    outputLabel.setText(String.valueOf(left*right));
                    break;
                case "+":
                    outputLabel.setText(String.valueOf(left + right));
                    break;
                case "-":
                    outputLabel.setText(String.valueOf(left - right));
                default:
                    outputLabel.setText("Invalid operator");
            }
            leftField.clear();
            rightField.clear();
            
            currentOperator = operator;
            
        } catch (NumberFormatException e){
            outputLabel.setText("Invalid input");
        }
        
    }
}