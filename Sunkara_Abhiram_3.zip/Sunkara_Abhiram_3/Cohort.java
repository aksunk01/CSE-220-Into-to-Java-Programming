

import java.util.ArrayList;

public class Cohort{
    private String firstName, lastName;
    private Address homeAddress, schoolAddress;

    private ArrayList<Student> students;
    public Cohort(){
        this.students = new ArrayList<>();

    }

    public void addStudent(Student newStudent){
        students.add(newStudent);
    }

    public Student getStudentByAddressMatch(Address homeA, Address schoolA) {
        
        for (Student student : students) {
            if (student.getHomeAddress().equals(homeA) && student.getSchoolAddress().equals(schoolA)) {
                return student;
            }
        }
        
        return null;
    }

    public Student getStudentLongestLastName() {
        if (students.isEmpty()) {
            return null; // No students in the cohort
        }

        Student longestStudent = students.get(0); // Initialize with first student
        int maxLength = longestStudent.getLastName().length();

        for (Student student : students) {
            int currentLength = student.getLastName().length();
            if (currentLength > maxLength || currentLength == maxLength) {
                longestStudent = student;
                maxLength = currentLength;
            }
        }

        return longestStudent;
    }

    public String toString(){
        String result;

        result = firstName + " " + lastName + "\n";
        result += "Home Address:\n" + homeAddress + "\n";
        result += "School Address:\n" + schoolAddress;

        return result;
    }

}

