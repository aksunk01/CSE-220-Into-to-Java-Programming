 

import java.util.ArrayList;
public class PolyDriver
{
    public static void main(String[] args)
    {
        //Check that exception is thrown when 3 sides are used for rectangle
        ArrayList<Double> mydimr1 = new ArrayList<Double>();
        mydimr1.add(4.0); mydimr1.add(3.0); mydimr1.add(5.0);     
        try {
            Rectangle myrect1 = new Rectangle(mydimr1);
            System.out.println("This line shouldn't be printed -- Rectangle with 3 sides has been constructed!");        }
        catch (Exception e) {
            System.out.println("Rectangle with 3 sides was correctly rejected.");
        }   
        
        //Test if exception is thrown when bad dimensions used for right triangle
        ArrayList<Double> mydimr2 = new ArrayList<Double>();
        mydimr2.add(5.0); mydimr2.add(6.0); mydimr2.add(7.0); mydimr2.add(8.0);
        try {
            Rectangle myrect2 = new Rectangle(mydimr2);
            System.out.println("This line shouldn't be printed -- rectangle with mismatched dimensions has been constructed!");        
        }
        catch (Exception e) {
            System.out.println("Rectangle with mismatched dimensions was correctly rejected");
        }               
        //Test if area and perimeter correctly computed for valid rectangle
        ArrayList<Double> mydimr3 = new ArrayList<Double>();
        mydimr3.add(5.0); mydimr3.add(8.0); mydimr3.add(5.0); mydimr3.add(8.0);
        try {
            Rectangle myrect3 = new Rectangle(mydimr3);
            System.out.println(" Valid Rectangle Perimeter: " + myrect3.computePerimeter());
            System.out.println(" Valid Rectangle Area: " + myrect3.computeArea());
        }
        catch (Exception e) {
            System.out.println("Exception incorrectly thrown for valid rectangle.");
        }           

        //Check that exception is thrown when 9 sides are used for octagon
        ArrayList<Double> mydimo1 = new ArrayList<Double>();
        mydimo1.add(4.0); mydimo1.add(4.0); mydimo1.add(4.0); mydimo1.add(4.0); mydimo1.add(4.0);
        mydimo1.add(4.0); mydimo1.add(4.0); mydimo1.add(4.0); mydimo1.add(4.0);
        try {
            Octagon myoct1 = new Octagon(mydimo1);
            System.out.println("This line shouldn't be printed -- Octagon with 9 sides has been constructed!");        }
        catch (Exception e) {
            System.out.println("Octagon with 9 sides was correctly rejected.");
        }   
        
        //Test if exception is thrown when bad dimensions used for octagon
        ArrayList<Double> mydimo2 = new ArrayList<Double>();
        mydimo2.add(4.0); mydimo2.add(4.0); mydimo2.add(4.0); mydimo2.add(4.0);
        mydimo2.add(4.0); mydimo2.add(4.0); mydimo2.add(6.0); mydimo2.add(4.0);
        try {
            Octagon myoct2 = new Octagon(mydimo2);
            System.out.println("This line shouldn't be printed -- octagon with irregular sides accepted!");        }
        catch (Exception e) {
            System.out.println("Octagon with irregular sides was correctly rejected.");
        }   

        ArrayList<Double> mydimo3 = new ArrayList<Double>();
        mydimo3.add(4.0); mydimo3.add(4.0); mydimo3.add(4.0); mydimo3.add(4.0);
        mydimo3.add(4.0); mydimo3.add(4.0); mydimo3.add(4.0); mydimo3.add(4.0);
        try {
            Octagon myoct3 = new Octagon(mydimo3);
            System.out.println(" Regular Octagon Perimeter: " + myoct3.computePerimeter());
            System.out.println(" Regular Octagon Area: " + myoct3.computeArea());
        }
        catch (Exception e) {
            //System.out.println("Exception incorrectly thrown for regular octagon.");
            System.out.println(e);
        }           
 
        
    }
}



public abstract class Polygon {

    protected ArrayList<Double> sides; // Make sides protected for inheritance
  
    public Polygon(ArrayList<Double> sides) throws Exception {
      if (sides == null || sides.size() < 3) {
        throw new IllegalArgumentException("Polygon must have at least 3 sides.");
      }
      this.sides = new ArrayList<>(sides); // Create a copy of the input list
    }
  
    public Double computePerimeter() {
      double perimeter = 0.0;
      for (Double side : sides) {
        perimeter += side;
      }
      return perimeter;
    }
  
    public abstract Double computeArea(); // Abstract method for subclasses to implement
  }
  
  public class Rectangle extends Polygon {
  
    public Rectangle(ArrayList<Double> sides) throws Exception {
      super(sides); // Call parent constructor for basic validation
      if (sides.size() != 4 || !almostEqual(sides.get(0), sides.get(2)) || !almostEqual(sides.get(1), sides.get(3))) {
        throw new IllegalArgumentException("Rectangle must have 4 sides with opposite sides equal.");
      }
    }
  
    @Override
    public Double computeArea() {
      return sides.get(0) * sides.get(1); // Assuming width is side 1 and height is side 2
    }
  
    // Helper method to compare doubles with a tolerance for floating-point errors
    private boolean almostEqual(double a, double b) {
      return Math.abs(a - b) < 0.001; // Adjust tolerance as needed
    }
  }
  
  public class RegularOctagon extends Polygon {
  
    public RegularOctagon(ArrayList<Double> sides) throws Exception {
      super(sides); // Call parent constructor for basic validation
      if (sides.size() != 8) {
        throw new IllegalArgumentException("Regular Octagon must have 8 sides.");
      }
      for (int i = 1; i < sides.size(); i++) {
        if (!almostEqual(sides.get(0), sides.get(i))) {
          throw new IllegalArgumentException("Regular Octagon must have all sides equal.");
        }
      }
    }
  
    @Override
    public Double computeArea() {
      double side = sides.get(0); // Assuming all sides are equal
      return 2 * Math.pow(side, 2) * (1 + Math.sqrt(2));
    }
  }