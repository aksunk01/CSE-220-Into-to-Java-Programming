import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ColorPicker;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;

public class InteractiveHouse extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Define colors for house components
        Color bodyColor = Color.LIGHTCORAL;
        Color roofColor = Color.BROWN;
        Color doorColor = Color.BLUE; // This will be changeable
        Color windowColor = Color.WHITE;

        // Define dimensions for house components
        double houseWidth = 400;
        double houseHeight = 200;
        double doorWidth = houseWidth / 4;
        double doorHeight = houseHeight / 3;
        double windowWidth = houseWidth / 7;
        double windowHeight = windowWidth;

        // Create the house components
        
        Rectangle top = new Rectangle(0,0,400,100);
        top.setFill(Color.WHITE);
        
        Rectangle body = new Rectangle(0, 0, houseWidth, houseHeight);
        body.setFill(bodyColor);

        Polygon roof = new Polygon(0, houseHeight, houseWidth / 2, houseHeight - houseHeight / 3, houseWidth, houseHeight);
        roof.setFill(roofColor);
        roof.setLayoutY(-150);

        Rectangle door = new Rectangle(houseWidth / 2 - doorWidth / 2, houseHeight - doorHeight, doorWidth, doorHeight);
        door.setFill(doorColor); // Initially set to blue

        Circle window1 = new Circle(houseWidth / 3, houseHeight - 2 * windowHeight, windowWidth / 2);
        window1.setLayoutX(-50);
        window1.setLayoutY(10);
        window1.setFill(windowColor);

        Rectangle window2 = new Rectangle(2 * houseWidth / 3, houseHeight - 2 * windowHeight, windowWidth, windowHeight);
        window2.setFill(windowColor);

        // Create the color picker for the door
        ColorPicker colorPicker = new ColorPicker(doorColor);
        colorPicker.setLayoutX(houseWidth + 20);
        colorPicker.setLayoutY(100);

        // Bind the door fill color to the color picker selection
        door.fillProperty().bind(colorPicker.valueProperty());

        // Create the scene and add elements
        Pane root = new Pane();
        root.getChildren().addAll(top,body, roof, door, window1, window2, colorPicker);

        Scene scene = new Scene(root, 600, 400);

        primaryStage.setTitle("Interactive House");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}